using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/get-cache")]
public class GetCacheController : ControllerBase
{
    private readonly IMySqlProvider _cacheProvider;

    public GetCacheController(IMySqlProvider cacheProvider)
    {
        _cacheProvider = cacheProvider;
    }

    [HttpGet]
    public IActionResult GetCache([FromQuery] string key)
    {
        var value = _cacheProvider.GetData(key);
        if (string.IsNullOrEmpty(value))
            return NotFound("Cache key not found");

        return Ok(value);
    }

  
}
