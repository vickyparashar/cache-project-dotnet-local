using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/set-cache")]
public class SetCacheController : ControllerBase
{
    private readonly IMySqlProvider _cacheProvider;

    public SetCacheController(IMySqlProvider cacheProvider)
    {
        _cacheProvider = cacheProvider;
    }

    [HttpPost]
    public IActionResult SetCache([FromQuery] string key, [FromQuery] string value)
    {
        _cacheProvider.AddData(key, value);
        return Ok("Cache added successfully");
    }
}
