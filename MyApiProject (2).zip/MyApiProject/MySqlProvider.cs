using Microsoft.Extensions.Caching.Distributed;
using System;

public class MySqlProvider : IMySqlProvider
{
    private readonly IDistributedCache _cache;
    private readonly string _connectionString;

    public MySqlProvider(IDistributedCache cache, string connectionString)
    {
        _cache = cache;
        _connectionString = connectionString;
    }

    public void AddData(string key, string value)
    {
        var options = new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(30)
        };
        _cache.SetString(key, value, options);
        Console.WriteLine($"Data added to cache with key: {_cache.GetHashCode().ToString()}");
    }

    public string? GetData(string key)
    {
        var value = _cache.GetString(key);

        Console.WriteLine($"Data added to cache with key: {_cache.GetHashCode().ToString()}");
        return value;
    }

    public string GetConnectionString()
    {
        return _connectionString;
    }
}
