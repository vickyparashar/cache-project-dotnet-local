using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Caching.Distributed;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddDistributedMemoryCache();

// Define a sample connection string
string mySqlConnectionString = "Server=myserver;Database=mydb;User=myuser;Password=mypassword;";

// Register MySqlProvider with the connection string
builder.Services.AddSingleton<IMySqlProvider>(provider =>
    new MySqlProvider(provider.GetRequiredService<IDistributedCache>(), mySqlConnectionString));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middleware pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
