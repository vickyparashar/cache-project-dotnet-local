public interface IMySqlProvider
{
    void AddData(string key, string value);
    string? GetData(string key);
}
