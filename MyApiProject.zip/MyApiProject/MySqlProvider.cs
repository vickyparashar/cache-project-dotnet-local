using Microsoft.Extensions.Caching.Distributed;
using System;

public class MySqlProvider : IMySqlProvider
{
    private readonly IDistributedCache _cache;
    private readonly string _connectionString;

    public MySqlProvider(IDistributedCache cache, string connectionString)
    {
        _cache = cache;
        _connectionString = connectionString;
    }

    public void AddData(string key, string value)
    {
        var options = new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(30)
        };
        _cache.SetString(key, value, options);
    }

    public string? GetData(string key)
    {
        return _cache.GetString(key);
    }

    public string GetConnectionString()
    {
        return _connectionString;
    }
}
